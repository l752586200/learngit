#pragma once


class OPERATOR
{
public:
};
class Operator4:public OPERATOR
{
public:
    void OPerator();
	void OPErator();
};
class Operator1 :public OPERATOR
{
public:

void OPerator2();
};
class Operator2 :public OPERATOR
{
public:
	void OPerator3();

};
class Operator3 :public OPERATOR
{
public:
	void OPerator4();

};